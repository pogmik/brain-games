### Hexlet tests and linter status:
[![Actions Status](https://github.com/pogmik/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/pogmik/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/8dc2b4b41087bf494759/maintainability)](https://codeclimate.com/github/pogmik/python-project-49/maintainability)
https://asciinema.org/a/ugvef9t8Ars21Kl4pE3Q4wRXp << brain-calc
https://asciinema.org/a/RyzOIBWoVfAflCKltttvLw3iY << brain-even
https://asciinema.org/a/qBRAfAOsm1ZDSoYa1Klz0p7po << brain-gcd
https://asciinema.org/a/lyJMQHbFfchFcHqUrUGUyWWma << brain-progression
