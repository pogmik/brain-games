from brain_games.games.func_calc import *

game_calc()