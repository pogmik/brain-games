from brain_games.games.func_prime import *

game_prime()

