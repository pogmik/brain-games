from brain_games.games.func_progression import *

game_progression()