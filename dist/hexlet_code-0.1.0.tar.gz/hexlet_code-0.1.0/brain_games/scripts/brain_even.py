from brain_games.engine import play
from brain_games.games import func_even


def main():
    play(func_even)


if __name__ == '__main__':
    main()
