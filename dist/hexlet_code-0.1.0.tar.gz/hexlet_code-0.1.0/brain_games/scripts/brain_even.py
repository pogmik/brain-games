from brain_games.games.func_even import game_even

game_even()

if __name__ == "__main__":
    game_even()