from brain_games.games.func_gcd import *

game_gcd()
